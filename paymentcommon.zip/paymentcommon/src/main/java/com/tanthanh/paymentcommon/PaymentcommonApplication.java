package com.tanthanh.paymentcommon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentcommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentcommonApplication.class, args);
	}

}
